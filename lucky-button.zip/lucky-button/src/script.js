const buttons = document.querySelectorAll('.button');
const scoreDisplay = document.getElementById('score');
let score = 0;

function updateScore() {
  scoreDisplay.textContent = 'Punkte: ' + score;
}

function handleButtonClick() {
  const randomNumber = Math.floor(Math.random() * 100) + 1;
  const button = this;

  if (randomNumber === 100) {
    score += 5;
    updateScore();
    alert('Du hast eine Spezialkarte gefunden! +5 Punkte!');
  } else if (randomNumber >= 90) {
    score = 0;
    updateScore();
    alert('Du hast verloren! Deine Punkte wurden auf 0 zurückgesetzt.');
  } else {
    score++;
    updateScore();
  }


}

buttons.forEach(button => {
  button.addEventListener('click', handleButtonClick);
});
